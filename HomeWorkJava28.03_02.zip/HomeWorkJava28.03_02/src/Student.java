public class Student {
    private String name;
    private int group;

    public Student(String name){
        this.name = name;
    }

    public Student (String name, int group){
        this(name);
        this.group = group;
    }
    public Student(Student newStudent){
        this.name = newStudent.name;
        this.group = newStudent.group;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }
}


//6 В основной программе создайте переменную student1, проинициализируйте её с помощью оператора new и с помощью конструктора.
//7 В переменную student2 присвойте значение student1.
//8 В переменную student3 присвойте значение, полученное с помощью клонирующего конструктора.
//9 Измените значение поля name у student1.
//10 Выведите на консоль значения полей student1, student2 и student3.

public class Main {

    public static void main(String[] args) {
        Student student1 = new Student("Олег", 1);
        Student student2 = student1;
        Student student3 = new Student(student1);
        student1.setName("Вениамин");
        System.out.println("Имя студента #1: " + student1.getName() + " Группа: " + student1.getGroup());
        System.out.println("Имя студента #2: " + student2.getName() + " Группа: " + student2.getGroup());
        System.out.println("Имя студента #3: " + student3.getName() + " Группа: " + student3.getGroup());
    }
}
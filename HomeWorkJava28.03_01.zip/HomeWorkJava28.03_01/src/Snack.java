public enum Snack {
    CHIPS, SNICKERS, COLA, PEPSI
}
